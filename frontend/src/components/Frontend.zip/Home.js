import React from 'react';

const Home = () => {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Bem-vindo ao Projeto!</h1>
      </header>
    <form>

    <p>Sistema voltado para BPA e DashBoard do e-SUS AB</p>

      <footer className="home-footer">
      </footer>
      </form>

    </div>
  );
};

export default Home;
